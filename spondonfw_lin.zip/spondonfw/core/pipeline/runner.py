"""
SpondonFW - Pipeline Runner
Orchestrates modules in sequence according to a YAML pipeline config.
Supports: dependency resolution, conditional execution, resume, parallel tasks.
"""

import yaml
import uuid
import time
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from core.loader.module_loader import ModuleLoader
from core.engine.session import SessionManager
from utils.logger import get_logger

logger = get_logger("pipeline.runner")


class PipelineStage:
    """Represents one stage (step) in a pipeline."""

    def __init__(self, config: Dict):
        self.id = config.get("id", str(uuid.uuid4())[:8])
        self.name = config["name"]
        self.module = config["module"]
        self.description = config.get("description", "")
        self.enabled = config.get("enabled", True)
        self.parallel = config.get("parallel", False)
        self.depends_on: List[str] = config.get("depends_on", [])
        self.condition: Optional[str] = config.get("condition", None)
        self.args: Dict = config.get("args", {})
        self.on_failure: str = config.get("on_failure", "continue")  # continue | abort
        self.timeout: int = config.get("timeout", 3600)


class PipelineRunner:
    """
    Loads a YAML pipeline config and runs modules stage-by-stage.

    Pipeline YAML format:
    ─────────────────────
    name: full_scan
    description: Complete methodology pipeline
    version: "1.0"
    stages:
      - id: recon_subdomains
        name: Subdomain Enumeration
        module: recon.subdomains
        args:
          passive_only: false
        on_failure: continue

      - id: recon_dns
        name: DNS Enumeration
        module: recon.dns
        depends_on: [recon_subdomains]
        condition: "results.recon_subdomains.findings | length > 0"
    """

    def __init__(self, target: str, pipeline_config: str,
                 output_dir: str = "results/",
                 resume: bool = False,
                 rate_limit: int = 10,
                 extra: Optional[Dict] = None):
        self.target = target
        self.pipeline_config_path = pipeline_config
        self.output_dir = Path(output_dir) / target.replace(".", "_")
        self.resume = resume
        self.rate_limit = rate_limit
        self.extra = extra or {}

        self.session_id = str(uuid.uuid4())
        self.session_manager = SessionManager()
        self.loader = ModuleLoader()
        self.config = self._load_pipeline(pipeline_config)
        self.stages: List[PipelineStage] = self._parse_stages()

        # Execution state
        self.results: Dict[str, Any] = {}
        self.stage_status: Dict[str, str] = {}

    def _load_pipeline(self, path: str) -> Dict:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Pipeline config not found: {path}")
        with open(p) as f:
            return yaml.safe_load(f)

    def _parse_stages(self) -> List[PipelineStage]:
        return [PipelineStage(s) for s in self.config.get("stages", [])]

    def execute(self) -> Dict:
        """Main execution loop."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Create or resume session
        if self.resume:
            session = self.session_manager.load_last_session(self.target)
            if session:
                self.session_id = session["id"]
                self.stage_status = session.get("stage_status", {})
                self.results = session.get("results", {})
                logger.info(f"Resuming session {self.session_id} for {self.target}")
        
        session_data = self.session_manager.create_session(
            session_id=self.session_id,
            target=self.target,
            pipeline=self.config.get("name", "custom"),
            output_dir=str(self.output_dir)
        )

        logger.info(f"Pipeline: {self.config.get('name', 'unnamed')} | Target: {self.target}")
        logger.info(f"Stages: {len(self.stages)} | Session: {self.session_id}")

        start_time = time.time()

        for stage in self.stages:
            # Skip already completed stages when resuming
            if self.resume and self.stage_status.get(stage.id) == "success":
                logger.info(f"⏭  Skipping (already done): {stage.name}")
                continue

            # Check if stage is enabled
            if not stage.enabled:
                logger.info(f"⏭  Stage disabled: {stage.name}")
                self.stage_status[stage.id] = "disabled"
                continue

            # Check dependencies
            if not self._dependencies_met(stage):
                logger.warning(f"⛔ Dependencies not met for: {stage.name}")
                self.stage_status[stage.id] = "skipped_deps"
                continue

            # Evaluate condition
            if stage.condition and not self._evaluate_condition(stage.condition):
                logger.info(f"⏭  Condition false, skipping: {stage.name}")
                self.stage_status[stage.id] = "skipped_cond"
                continue

            # Run the stage
            result = self._run_stage(stage)
            self.results[stage.id] = result
            self.stage_status[stage.id] = result.status

            # Save checkpoint after each stage
            self._save_checkpoint()

            if result.status == "failed" and stage.on_failure == "abort":
                logger.error(f"Pipeline aborted at stage: {stage.name}")
                break

        total_time = time.time() - start_time
        summary = self._build_summary(total_time)

        # Save final summary
        summary_path = self.output_dir / "pipeline_summary.json"
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2)

        self.session_manager.update_session(
            self.session_id, status="completed", summary=summary
        )

        logger.info(f"Pipeline complete in {total_time:.1f}s | "
                    f"Findings: {summary['total_findings']}")

        return summary

    def _run_stage(self, stage: PipelineStage) -> Any:
        """Load and run a single module stage."""
        from rich.console import Console
        console = Console()

        console.print(f"\n[bold cyan]▶ Stage:[/bold cyan] {stage.name} "
                      f"[dim]({stage.module})[/dim]")

        try:
            mod = self.loader.load(stage.module)
        except Exception as e:
            logger.error(f"Failed to load module {stage.module}: {e}")
            from core.engine.base_module import ModuleResult
            r = ModuleResult(module_name=stage.module, target=self.target)
            r.status = "failed"
            r.error = f"Module load error: {e}"
            return r

        # Build ctx: merge global extra + stage args + previous results
        stage_ctx = {
            **self.extra,
            **stage.args,
            "previous_results": self.results,
        }

        result = mod.run(
            target=self.target,
            output_dir=str(self.output_dir / stage.id),
            session_id=self.session_id,
            rate_limit=self.rate_limit,
            **stage_ctx
        )

        status_icon = "✓" if result.status == "success" else "✗"
        color = "green" if result.status == "success" else "red"
        console.print(f"[{color}]{status_icon} {stage.name}[/{color}]  "
                      f"[dim]{len(result.findings)} findings | "
                      f"{result.duration:.1f}s[/dim]")

        return result

    def _dependencies_met(self, stage: PipelineStage) -> bool:
        for dep in stage.depends_on:
            status = self.stage_status.get(dep)
            if status not in ("success", "skipped_cond", "disabled"):
                return False
        return True

    def _evaluate_condition(self, condition: str) -> bool:
        """
        Simple condition evaluator.
        Supports:
          - "results.STAGE_ID.findings | length > N"
          - "results.STAGE_ID.status == 'success'"
        """
        try:
            # Replace results.X.Y with actual values
            import re
            def replacer(m):
                stage_id = m.group(1)
                attr = m.group(2)
                res = self.results.get(stage_id)
                if res is None:
                    return "None"
                val = getattr(res, attr, None)
                if val is None:
                    val = res.to_dict().get(attr)
                return repr(val)

            expr = re.sub(r'results\.(\w+)\.(\w+)', replacer, condition)
            expr = re.sub(r'\|\s*length', '', expr)
            return bool(eval(expr))
        except Exception as e:
            logger.warning(f"Condition eval error: {e}")
            return True  # Default: run the stage

    def _save_checkpoint(self):
        cp = self.output_dir / ".checkpoint.json"
        state = {
            "session_id": self.session_id,
            "target": self.target,
            "stage_status": self.stage_status,
        }
        with open(cp, "w") as f:
            json.dump(state, f, indent=2)

    def _build_summary(self, total_time: float) -> Dict:
        total_findings = 0
        findings_by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        stage_summaries = []

        for stage_id, result in self.results.items():
            if hasattr(result, 'findings'):
                for f in result.findings:
                    total_findings += 1
                    sev = f.get("severity", "info")
                    findings_by_severity[sev] = findings_by_severity.get(sev, 0) + 1
                stage_summaries.append({
                    "stage_id": stage_id,
                    "status": result.status,
                    "findings": len(result.findings),
                    "duration": result.duration
                })

        return {
            "session_id": self.session_id,
            "target": self.target,
            "pipeline": self.config.get("name", "custom"),
            "total_time_seconds": round(total_time, 2),
            "total_findings": total_findings,
            "findings_by_severity": findings_by_severity,
            "stages": stage_summaries,
            "stage_status": self.stage_status
        }
