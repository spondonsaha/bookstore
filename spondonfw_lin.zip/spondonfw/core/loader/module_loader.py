"""
SpondonFW - Module Loader
Dynamically discovers, loads, and validates framework modules.
Supports both built-in modules and plugins.
"""

import importlib
import importlib.util
import pkgutil
import sys
from pathlib import Path
from typing import Dict, List, Optional, Type
from utils.logger import get_logger

logger = get_logger("module.loader")

# Built-in module registry: dotted_path -> class_name
MODULE_REGISTRY = {
    # ── Recon ────────────────────────────────────────────────
    "recon.subdomains":     ("modules.recon.subdomains.subdomain_enum", "SubdomainEnum"),
    "recon.dns":            ("modules.recon.dns.dns_recon", "DnsRecon"),
    "recon.whois":          ("modules.recon.whois.whois_lookup", "WhoisLookup"),
    "recon.shodan":         ("modules.recon.shodan.shodan_lookup", "ShodanLookup"),
    "recon.github":         ("modules.recon.github_dorking.github_dork", "GithubDork"),
    "recon.wayback":        ("modules.recon.subdomains.wayback_urls", "WaybackURLs"),

    # ── Enumeration ──────────────────────────────────────────
    "enum.webcrawl":        ("modules.enumeration.web_crawl.crawler", "WebCrawler"),
    "enum.js_analysis":     ("modules.enumeration.js_analysis.js_analyzer", "JSAnalyzer"),
    "enum.params":          ("modules.enumeration.param_discovery.param_finder", "ParamFinder"),
    "enum.dirfuzz":         ("modules.enumeration.dir_fuzz.dir_fuzzer", "DirFuzzer"),
    "enum.api_endpoints":   ("modules.enumeration.api_endpoints.api_enum", "APIEnumerator"),

    # ── Vulnerability Scanning ───────────────────────────────
    "vuln.xss":             ("modules.vulnscan.xss.xss_scanner", "XSSScanner"),
    "vuln.sqli":            ("modules.vulnscan.sqli.sqli_scanner", "SQLiScanner"),
    "vuln.ssrf":            ("modules.vulnscan.ssrf.ssrf_scanner", "SSRFScanner"),
    "vuln.idor":            ("modules.vulnscan.idor.idor_scanner", "IDORScanner"),
    "vuln.auth":            ("modules.vulnscan.auth.auth_tester", "AuthTester"),
    "vuln.business_logic":  ("modules.vulnscan.business_logic.bl_tester", "BusinessLogicTester"),
    "vuln.open_redirect":   ("modules.vulnscan.open_redirect.or_scanner", "OpenRedirectScanner"),
    "vuln.lfi":             ("modules.vulnscan.lfi.lfi_scanner", "LFIScanner"),

    # ── Reporting ────────────────────────────────────────────
    "reporting.html":       ("modules.reporting.html_report", "HTMLReport"),
    "reporting.markdown":   ("modules.reporting.md_report", "MarkdownReport"),
    "reporting.json":       ("modules.reporting.json_report", "JSONReport"),
}

# Human-friendly category descriptions
CATEGORY_META = {
    "recon":      "Passive & active reconnaissance",
    "enum":       "Enumeration & asset fingerprinting",
    "vuln":       "Vulnerability detection",
    "reporting":  "Report generation",
    "plugin":     "Community plugins",
}


class ModuleLoader:
    """
    Loads modules by dotted path name.
    Falls back to plugin directory if not found in registry.
    """

    def __init__(self, plugin_dirs: Optional[List[str]] = None):
        self.plugin_dirs = plugin_dirs or ["plugins/"]
        self._cache: Dict[str, object] = {}

    def load(self, dotted_path: str):
        """
        Load and instantiate a module by dotted path.

        Example:
            loader.load("recon.subdomains")   -> SubdomainEnum instance
            loader.load("vuln.xss")           -> XSSScanner instance
        """
        if dotted_path in self._cache:
            return self._cache[dotted_path]

        if dotted_path in MODULE_REGISTRY:
            module_path, class_name = MODULE_REGISTRY[dotted_path]
            instance = self._import_and_instantiate(module_path, class_name)
        else:
            # Try loading from plugins
            instance = self._load_from_plugins(dotted_path)
            if instance is None:
                raise ModuleNotFoundError(
                    f"Module '{dotted_path}' not found in registry or plugins.\n"
                    f"Run `spondonfw module list` to see available modules."
                )

        self._cache[dotted_path] = instance
        return instance

    def _import_and_instantiate(self, module_path: str, class_name: str):
        """Import a Python module and instantiate the named class."""
        try:
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            return cls()
        except ModuleNotFoundError as e:
            logger.error(f"Cannot import {module_path}: {e}")
            raise
        except AttributeError:
            logger.error(f"Class {class_name} not found in {module_path}")
            raise

    def _load_from_plugins(self, dotted_path: str):
        """Try loading module from plugin directories."""
        for plugin_dir in self.plugin_dirs:
            # Convert dotted path to file path
            parts = dotted_path.split(".")
            candidate = Path(plugin_dir) / Path(*parts[:-1]) / f"{parts[-1]}.py"
            if candidate.exists():
                spec = importlib.util.spec_from_file_location(dotted_path, str(candidate))
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                # Convention: plugin exports a class matching the filename in PascalCase
                cls_name = "".join(p.capitalize() for p in parts[-1].split("_"))
                cls = getattr(mod, cls_name, None)
                if cls:
                    return cls()
        return None

    def discover(self) -> Dict[str, List[Dict]]:
        """
        Return all available modules grouped by category.
        Used by `spondonfw module list`.
        """
        from core.engine.base_module import BaseModule

        discovered: Dict[str, List[Dict]] = {}

        for dotted_path, (module_path, class_name) in MODULE_REGISTRY.items():
            category = dotted_path.split(".")[0]
            if category not in discovered:
                discovered[category] = []

            try:
                instance = self.load(dotted_path)
                discovered[category].append({
                    "name": dotted_path,
                    "description": instance.description,
                    "tools": instance.tools_required,
                    "tags": instance.tags,
                })
            except Exception:
                # Module may have missing deps — still list it
                discovered[category].append({
                    "name": dotted_path,
                    "description": "(load error — check dependencies)",
                    "tools": [],
                    "tags": [],
                })

        # Also discover plugins
        plugin_mods = self._discover_plugins()
        if plugin_mods:
            discovered["plugin"] = plugin_mods

        return discovered

    def _discover_plugins(self) -> List[Dict]:
        results = []
        for plugin_dir in self.plugin_dirs:
            p = Path(plugin_dir)
            if not p.exists():
                continue
            for pyfile in p.rglob("*.py"):
                if pyfile.stem.startswith("_"):
                    continue
                results.append({
                    "name": f"plugin.{pyfile.stem}",
                    "description": f"Plugin: {pyfile}",
                    "tools": [],
                    "tags": ["plugin"],
                })
        return results

    def register(self, dotted_path: str, module_path: str, class_name: str):
        """Dynamically register a new module (used by plugin system)."""
        MODULE_REGISTRY[dotted_path] = (module_path, class_name)
        logger.info(f"Registered module: {dotted_path}")
