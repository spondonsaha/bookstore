"""
SpondonFW setup
"""
from setuptools import setup, find_packages

setup(
    name="spondonfw",
    version="1.0.0",
    description="Modular Bug Bounty / Pentesting Framework by Spondon Saha",
    author="Spondon Saha",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[
        "click>=8.1",
        "rich>=13.0",
        "pyyaml>=6.0",
        "requests>=2.31",
        "urllib3>=2.0",
    ],
    entry_points={
        "console_scripts": [
            "spondonfw=cli.main:cli",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "Programming Language :: Python :: 3.9",
    ],
)
