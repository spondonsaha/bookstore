"""
SpondonFW - Recon Module: Wayback URL Collection
Collects historical URLs from Wayback Machine, gau, and katana.
Filters and categorises URLs for use by param discovery and dir fuzzing.
"""
import json
import re
import time
from pathlib import Path
from typing import Dict, List, Set
from urllib.parse import urlparse, parse_qs

import requests

from core.engine.base_module import BaseModule, ModuleResult


# URL patterns worth highlighting
INTERESTING_PATTERNS = {
    "admin":    r"/(admin|administrator|manage|management|portal|dashboard|console)",
    "api":      r"/(api|v[0-9]+|graphql|rest|rpc|swagger|openapi)",
    "auth":     r"/(login|logout|signin|signup|register|auth|oauth|sso|saml|token|password|reset)",
    "upload":   r"/(upload|file|attachment|import|export|backup)",
    "config":   r"\.(env|config|cfg|conf|ini|yaml|yml|json|xml|bak|old|backup|sql|db)",
    "debug":    r"/(debug|test|dev|staging|phpinfo|info\.php|\.git|\.svn)",
}

# Extensions to drop (static assets)
SKIP_EXTENSIONS = {
    "png", "jpg", "jpeg", "gif", "svg", "ico", "woff", "woff2",
    "ttf", "eot", "mp4", "mp3", "webm", "pdf", "zip"
}


class WaybackURLs(BaseModule):
    name = "recon.wayback"
    description = "Historical URL collection from Wayback Machine, gau, katana"
    category = "recon"
    tools_required = ["waybackurls", "gau", "katana"]
    input_schema  = {"target": "str — root domain"}
    output_schema = {
        "findings": "Interesting historical URLs and patterns",
        "files": {
            "wayback_urls.txt":     "all deduplicated URLs",
            "parameterised_urls.txt": "URLs with query params",
            "interesting_urls.txt": "flagged interesting paths",
        }
    }
    tags = ["recon", "wayback", "urls", "phase1"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        urls: Set[str] = set()

        # ── Source 1: waybackurls ────────────────────────────────────────────
        if self._tool_available("waybackurls"):
            self.logger.info("  Fetching from waybackurls...")
            raw = self._run_tool(f"echo {target} | waybackurls 2>/dev/null", timeout=120)
            found = {l.strip() for l in raw.splitlines() if l.strip().startswith("http")}
            urls.update(found)
            self.logger.info(f"  waybackurls: {len(found)} URLs")
        else:
            # Fallback: query Wayback CDX API directly
            self.logger.info("  waybackurls not found, using CDX API...")
            cdx_urls = self._cdx_api(target)
            urls.update(cdx_urls)
            self.logger.info(f"  CDX API: {len(cdx_urls)} URLs")

        # ── Source 2: gau ────────────────────────────────────────────────────
        if self._tool_available("gau"):
            self.logger.info("  Fetching from gau...")
            raw = self._run_tool(
                f"echo {target} | gau --subs --threads 5 2>/dev/null", timeout=120
            )
            found = {l.strip() for l in raw.splitlines() if l.strip().startswith("http")}
            new = found - urls
            urls.update(found)
            self.logger.info(f"  gau: +{len(new)} new URLs")

        # ── Source 3: katana quick spider ────────────────────────────────────
        if self._tool_available("katana"):
            self.logger.info("  Quick spider with katana...")
            raw = self._run_tool(
                f"katana -u https://{target} -silent -depth 2 -no-color 2>/dev/null",
                timeout=120
            )
            found = {l.strip() for l in raw.splitlines() if l.strip().startswith("http")}
            new = found - urls
            urls.update(found)
            self.logger.info(f"  katana: +{len(new)} new URLs")

        # ── Filter and categorise ────────────────────────────────────────────
        self.logger.info(f"Total raw URLs: {len(urls)} — filtering...")

        clean_urls: Set[str] = set()
        param_urls: Set[str] = set()
        interesting_urls: List[Dict] = []

        for url in urls:
            try:
                parsed = urlparse(url)
                ext = parsed.path.rsplit(".", 1)[-1].lower() if "." in parsed.path else ""
                if ext in SKIP_EXTENSIONS:
                    continue
                # Must be in scope
                if target not in parsed.netloc:
                    continue

                clean_urls.add(url)

                # Parameterised URLs
                if parsed.query:
                    param_urls.add(url)

                # Interesting pattern matching
                for category, pattern in INTERESTING_PATTERNS.items():
                    if re.search(pattern, url, re.IGNORECASE):
                        interesting_urls.append({"url": url, "category": category})
                        break

            except Exception:
                continue

        # ── Write output files ───────────────────────────────────────────────
        self._write_lines(str(out / "wayback_urls.txt"), sorted(clean_urls))
        self._write_lines(str(out / "parameterised_urls.txt"), sorted(param_urls))
        self._write_lines(str(out / "interesting_urls.txt"),
                          [f"[{i['category']}] {i['url']}" for i in interesting_urls])

        # ── Build findings ───────────────────────────────────────────────────
        result.add_finding(
            finding_type="wayback_url_count",
            value=f"{len(clean_urls)} historical URLs collected",
            severity="info",
            notes=f"{len(param_urls)} parameterised, {len(interesting_urls)} interesting"
        )

        for item in interesting_urls[:100]:  # cap findings at 100
            cat = item["category"]
            sev = "high" if cat in ("config", "debug") else "medium" if cat in ("admin", "auth") else "info"
            result.add_finding(
                finding_type=f"interesting_url_{cat}",
                value=item["url"],
                severity=sev,
                url=item["url"],
                notes=f"Pattern category: {cat}"
            )

        result.metadata = {
            "total_urls": len(clean_urls),
            "parameterised_urls": len(param_urls),
            "interesting_urls": len(interesting_urls),
            "output_files": {
                "all_urls": str(out / "wayback_urls.txt"),
                "param_urls": str(out / "parameterised_urls.txt"),
                "interesting": str(out / "interesting_urls.txt"),
            }
        }
        result.finished_at = time.time()
        return result

    def _cdx_api(self, domain: str) -> Set[str]:
        """Query Wayback CDX API directly — no tool required."""
        urls = set()
        try:
            resp = requests.get(
                "http://web.archive.org/cdx/search/cdx",
                params={
                    "url": f"*.{domain}/*",
                    "output": "text",
                    "fl": "original",
                    "collapse": "urlkey",
                    "limit": 50000,
                },
                timeout=30,
                stream=True,
            )
            for line in resp.iter_lines():
                url = line.decode("utf-8", errors="ignore").strip()
                if url.startswith("http"):
                    urls.add(url)
        except Exception as e:
            self.logger.warning(f"CDX API error: {e}")
        return urls
