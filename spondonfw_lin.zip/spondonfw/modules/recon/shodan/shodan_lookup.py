"""
SpondonFW - Recon Module: Shodan Lookup
Queries Shodan for open ports, banners, CVEs, and exposed services.
Falls back to shodan CLI if API key not configured.
"""
import json
import time
from pathlib import Path
from typing import Dict, List

import requests

from core.engine.base_module import BaseModule, ModuleResult
from utils.keystore import KeyStore


# Services worth flagging when exposed
INTERESTING_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
    80: "HTTP", 443: "HTTPS", 445: "SMB", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
    6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt",
    9200: "Elasticsearch", 27017: "MongoDB", 11211: "Memcached",
}

CRITICAL_PORTS = {23, 445, 3389, 5900, 6379, 9200, 27017, 11211}


class ShodanLookup(BaseModule):
    name = "recon.shodan"
    description = "Shodan search for open ports, service banners, CVEs on target IP ranges"
    category = "recon"
    tools_required = ["shodan"]
    input_schema = {
        "target": "str — root domain",
        "use_censys": "bool — also query Censys (requires censys_id + censys_secret keys)",
    }
    output_schema = {
        "findings": "Open ports, exposed services, CVEs",
        "files": {"shodan_results.json": "full Shodan data"},
    }
    tags = ["recon", "shodan", "ports", "phase1"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        ks = KeyStore()
        api_key = ks.get("shodan")

        if not api_key:
            self.logger.warning("No Shodan API key — set with: spondonfw config set-key shodan YOUR_KEY")
            self.logger.info("Trying shodan CLI fallback...")
            return self._cli_fallback(target, out, result)

        # ── Shodan API: domain search ────────────────────────────────────────
        try:
            # Resolve domain to IPs first
            ips = self._resolve_ips(target)
            all_data = []

            for ip in ips[:5]:  # cap at 5 IPs
                resp = requests.get(
                    f"https://api.shodan.io/shodan/host/{ip}",
                    params={"key": api_key},
                    timeout=15
                )
                if resp.status_code == 200:
                    host_data = resp.json()
                    all_data.append(host_data)
                    self._process_host(host_data, result)
                elif resp.status_code == 404:
                    self.logger.debug(f"No Shodan data for {ip}")
                else:
                    self.logger.warning(f"Shodan API error {resp.status_code} for {ip}")

            # Also do a domain search
            search_resp = requests.get(
                "https://api.shodan.io/shodan/host/search",
                params={"key": api_key, "query": f"hostname:{target}", "minify": True},
                timeout=15
            )
            if search_resp.status_code == 200:
                matches = search_resp.json().get("matches", [])
                for m in matches[:20]:
                    self._process_match(m, result)
                    all_data.append(m)

            (out / "shodan_results.json").write_text(json.dumps(all_data, indent=2))

        except Exception as e:
            self.logger.error(f"Shodan API error: {e}")
            return self._cli_fallback(target, out, result)

        result.finished_at = time.time()
        return result

    def _process_host(self, data: Dict, result: ModuleResult):
        ip = data.get("ip_str", "")
        ports = data.get("ports", [])
        hostnames = data.get("hostnames", [])
        vulns = data.get("vulns", {})
        os_info = data.get("os", "")

        result.add_finding("shodan_host", ip, severity="info",
                           notes=f"Hostnames: {', '.join(hostnames[:3])}, OS: {os_info}")

        for port in ports:
            sev = "high" if port in CRITICAL_PORTS else "medium" if port in INTERESTING_PORTS else "info"
            service = INTERESTING_PORTS.get(port, "unknown")
            result.add_finding(
                finding_type="open_port",
                value=f"{ip}:{port}",
                severity=sev,
                url=f"http://{ip}:{port}",
                notes=f"Service: {service}"
            )

        for cve_id, cve_data in vulns.items():
            cvss = cve_data.get("cvss", 0)
            sev = "critical" if cvss >= 9 else "high" if cvss >= 7 else "medium"
            result.add_finding(
                finding_type="cve",
                value=cve_id,
                severity=sev,
                url=f"https://nvd.nist.gov/vuln/detail/{cve_id}",
                evidence=f"CVSS: {cvss}",
                notes=cve_data.get("summary", "")[:200]
            )

    def _process_match(self, m: Dict, result: ModuleResult):
        ip = m.get("ip_str", "")
        port = m.get("port", 0)
        transport = m.get("transport", "tcp")
        sev = "high" if port in CRITICAL_PORTS else "medium" if port in INTERESTING_PORTS else "info"
        result.add_finding(
            finding_type="open_port",
            value=f"{ip}:{port}/{transport}",
            severity=sev,
            url=f"http://{ip}:{port}",
            notes=INTERESTING_PORTS.get(port, "")
        )

    def _cli_fallback(self, target: str, out: Path, result: ModuleResult) -> ModuleResult:
        if self._tool_available("shodan"):
            raw = self._run_tool(f"shodan domain {target} 2>/dev/null", timeout=30)
            (out / "shodan_cli.txt").write_text(raw)
            for line in raw.splitlines():
                if line.strip():
                    result.add_finding("shodan_cli_result", line.strip(), severity="info")
        else:
            result.add_finding(
                finding_type="shodan_skipped",
                value="Shodan API key not configured and CLI not installed",
                severity="info",
                notes="Install shodan CLI: pip install shodan && shodan init YOUR_KEY"
            )
        result.finished_at = time.time()
        return result

    def _resolve_ips(self, domain: str) -> List[str]:
        raw = self._run_tool(f"dig +short A {domain} 2>/dev/null", timeout=10)
        return [l.strip() for l in raw.splitlines() if re.match(r"\d+\.\d+\.\d+\.\d+", l.strip())]

    def _re_import(self):
        import re
        return re

import re
