"""
SpondonFW - Recon Module: GitHub Dorking
Searches GitHub for secrets, credentials, internal URLs, API keys
leaked in public repositories related to the target domain.
"""
import json
import time
import re
from pathlib import Path
from typing import Dict, List

import requests

from core.engine.base_module import BaseModule, ModuleResult
from utils.keystore import KeyStore


# GitHub search dorks per category
DORKS = {
    "secrets": [
        '"{domain}" password',
        '"{domain}" secret',
        '"{domain}" api_key',
        '"{domain}" apikey',
        '"{domain}" token',
        '"{domain}" credentials',
        '"{domain}" passwd',
    ],
    "config": [
        '"{domain}" filename:.env',
        '"{domain}" filename:config.yml',
        '"{domain}" filename:config.json',
        '"{domain}" filename:database.yml',
        '"{domain}" filename:settings.py',
        '"{domain}" filename:wp-config.php',
        '"{domain}" filename:.htpasswd',
    ],
    "internal": [
        '"{domain}" internal',
        '"{domain}" staging',
        '"{domain}" localhost',
        '"{domain}" 192.168',
        '"{domain}" 10.0.',
    ],
    "code": [
        '"{domain}" jdbc',
        '"{domain}" mongodb://',
        '"{domain}" redis://',
        '"{domain}" postgresql://',
        '"{domain}" mysql://',
    ],
}

# Patterns that indicate a real secret in code results
SECRET_INDICATORS = [
    r'password\s*[=:]\s*["\'][^"\']{4,}["\']',
    r'api[_-]?key\s*[=:]\s*["\'][^"\']{8,}["\']',
    r'secret\s*[=:]\s*["\'][^"\']{8,}["\']',
    r'token\s*[=:]\s*["\'][^"\']{8,}["\']',
    r'-----BEGIN\s+(?:RSA\s+)?PRIVATE KEY-----',
    r'AKIA[0-9A-Z]{16}',
    r'ghp_[A-Za-z0-9]{36}',
]


class GithubDork(BaseModule):
    name = "recon.github"
    description = "GitHub code search for leaked secrets, configs, internal URLs"
    category = "recon"
    tools_required = []
    input_schema = {
        "target": "str — root domain",
        "dork_categories": "list — subset of ['secrets','config','internal','code'] or 'all'",
    }
    output_schema = {
        "findings": "Leaked secrets, configs, internal references",
        "files": {"github_secrets.json": "all matches"},
    }
    tags = ["recon", "github", "secrets", "osint", "phase1"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        ks = KeyStore()
        token = ks.get("github")

        if not token:
            self.logger.warning("No GitHub token — rate limit will be very low (10 req/min)")
            self.logger.info("Set with: spondonfw config set-key github YOUR_TOKEN")

        headers = {"Accept": "application/vnd.github+json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Determine which categories to run
        categories = ctx.get("dork_categories", list(DORKS.keys()))
        if categories == "all" or not categories:
            categories = list(DORKS.keys())

        all_matches = []
        domain = target.replace("www.", "")

        for category in categories:
            if category not in DORKS:
                continue
            self.logger.info(f"  Dorking category: {category}")

            for dork_template in DORKS[category]:
                query = dork_template.format(domain=domain)
                matches = self._search_github(query, headers)

                for match in matches:
                    # Scan text snippet for actual secrets
                    snippet = match.get("text_matches", [{}])
                    snippet_text = " ".join(
                        m.get("fragment", "") for m in snippet
                    )
                    has_secret = any(
                        re.search(pat, snippet_text, re.IGNORECASE)
                        for pat in SECRET_INDICATORS
                    )

                    sev = "high" if has_secret else "medium" if category == "secrets" else "low"
                    repo = match.get("repository", {}).get("full_name", "unknown")
                    file_path = match.get("path", "")
                    html_url = match.get("html_url", "")

                    result.add_finding(
                        finding_type=f"github_{category}_leak",
                        value=f"{repo}/{file_path}",
                        severity=sev,
                        url=html_url,
                        evidence=snippet_text[:300] if snippet_text else f"Query: {query}",
                        notes=f"Category: {category} | Dork: {query}"
                    )
                    all_matches.append({
                        "category": category,
                        "query": query,
                        "repo": repo,
                        "file": file_path,
                        "url": html_url,
                        "has_secret_pattern": has_secret,
                        "snippet": snippet_text[:500],
                    })

                # Respect GitHub rate limits
                time.sleep(2 if token else 6)

        (out / "github_secrets.json").write_text(json.dumps(all_matches, indent=2))
        self.logger.info(f"GitHub dork matches: {len(all_matches)}")

        result.metadata = {
            "dorks_run": sum(len(DORKS[c]) for c in categories),
            "matches_found": len(all_matches),
        }
        result.finished_at = time.time()
        return result

    def _search_github(self, query: str, headers: Dict) -> List[Dict]:
        try:
            resp = requests.get(
                "https://api.github.com/search/code",
                params={"q": query, "per_page": 10},
                headers=headers,
                timeout=15,
            )
            if resp.status_code == 200:
                return resp.json().get("items", [])
            elif resp.status_code == 403:
                self.logger.warning("GitHub rate limit hit — sleeping 60s")
                time.sleep(60)
            elif resp.status_code == 422:
                self.logger.debug(f"GitHub rejected query: {query}")
        except Exception as e:
            self.logger.debug(f"GitHub search error: {e}")
        return []
