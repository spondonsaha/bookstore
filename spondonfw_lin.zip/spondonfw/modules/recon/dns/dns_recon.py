"""
SpondonFW - Recon Module: DNS Enumeration
Checks: zone transfers, DNS records (A/MX/TXT/NS/CNAME),
SPF/DMARC/DKIM misconfigs, wildcard detection, DNSSEC.
"""
import subprocess
import re
import time
from pathlib import Path
from typing import Dict, List

from core.engine.base_module import BaseModule, ModuleResult


class DnsRecon(BaseModule):
    name = "recon.dns"
    description = "DNS enumeration: zone transfers, MX/SPF/DMARC, wildcard, DNSSEC"
    category = "recon"
    tools_required = ["dig", "dnsx"]
    input_schema  = {"target": "str — root domain"}
    output_schema = {"findings": "DNS misconfigs and records", "files": {"dns_records.json": "all records"}}
    tags = ["recon", "dns", "phase1"]

    RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "CAA"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        # ── Zone transfer attempt ────────────────────────────────────────────
        ns_records = self._dig(target, "NS")
        for ns in ns_records:
            ns = ns.strip().rstrip(".")
            if not ns:
                continue
            raw = self._run_tool(f"dig axfr {target} @{ns} +noall +answer 2>&1", timeout=15)
            if "Transfer failed" not in raw and "connection refused" not in raw.lower() and len(raw) > 50:
                result.add_finding(
                    finding_type="dns_zone_transfer",
                    value=f"Zone transfer succeeded via {ns}",
                    severity="critical",
                    evidence=raw[:500],
                    notes="Zone transfer exposed — reveals all DNS records publicly"
                )

        # ── Standard record enumeration ──────────────────────────────────────
        records = {}
        for rtype in self.RECORD_TYPES:
            answers = self._dig(target, rtype)
            if answers:
                records[rtype] = answers
                for ans in answers:
                    result.add_finding(
                        finding_type=f"dns_{rtype.lower()}_record",
                        value=ans.strip(),
                        severity="info",
                        notes=f"DNS {rtype} record"
                    )

        # ── SPF check ────────────────────────────────────────────────────────
        txt_records = records.get("TXT", [])
        spf = [r for r in txt_records if "v=spf1" in r.lower()]
        if not spf:
            result.add_finding(
                finding_type="missing_spf",
                value=f"No SPF record found for {target}",
                severity="medium",
                notes="Missing SPF allows email spoofing"
            )
        else:
            for s in spf:
                if "+all" in s:
                    result.add_finding(
                        finding_type="permissive_spf",
                        value=s,
                        severity="high",
                        evidence=s,
                        notes="+all means ANY server can send email as this domain"
                    )

        # ── DMARC check ──────────────────────────────────────────────────────
        dmarc = self._dig(f"_dmarc.{target}", "TXT")
        if not dmarc:
            result.add_finding(
                finding_type="missing_dmarc",
                value=f"No DMARC record for {target}",
                severity="medium",
                notes="Missing DMARC — phishing/spoofing risk"
            )
        else:
            for d in dmarc:
                if "p=none" in d.lower():
                    result.add_finding(
                        finding_type="weak_dmarc",
                        value=d,
                        severity="low",
                        evidence=d,
                        notes="DMARC policy is 'none' — monitoring only, no enforcement"
                    )

        # ── DKIM check ───────────────────────────────────────────────────────
        for selector in ["default", "google", "mail", "dkim", "k1", "s1", "s2"]:
            dkim = self._dig(f"{selector}._domainkey.{target}", "TXT")
            if dkim:
                result.add_finding(
                    finding_type="dkim_record",
                    value=f"Selector: {selector}",
                    severity="info",
                    evidence="\n".join(dkim[:2]),
                    notes="DKIM record found"
                )
                break

        # ── Wildcard DNS detection ───────────────────────────────────────────
        wild = self._dig(f"thissubdomaindoesnotexist999.{target}", "A")
        if wild:
            result.add_finding(
                finding_type="wildcard_dns",
                value=f"Wildcard DNS active: *.{target} → {wild[0]}",
                severity="low",
                notes="Wildcard DNS — subdomain takeover checks may produce false positives"
            )

        # ── dnsx bulk resolution (if available) ─────────────────────────────
        if self._tool_available("dnsx"):
            raw = self._run_tool(
                f"echo {target} | dnsx -silent -a -mx -ns -txt -resp -json 2>/dev/null",
                timeout=30
            )
            (out / "dnsx_output.txt").write_text(raw)

        # Save records summary
        import json
        (out / "dns_records.json").write_text(json.dumps(records, indent=2))

        result.metadata = {"records_found": {k: len(v) for k, v in records.items()}}
        result.finished_at = time.time()
        return result

    def _dig(self, name: str, rtype: str) -> List[str]:
        raw = self._run_tool(f"dig +short {rtype} {name} 2>/dev/null", timeout=10)
        return [l.strip() for l in raw.splitlines() if l.strip()]
