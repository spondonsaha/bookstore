"""
SpondonFW - Recon Module: WHOIS & ASN Lookup
Gathers: registrar info, creation/expiry dates, ASN, IP ranges,
nameservers, registrant org. Flags expiring domains and interesting orgs.
"""
import json
import re
import time
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

import requests

from core.engine.base_module import BaseModule, ModuleResult


class WhoisLookup(BaseModule):
    name = "recon.whois"
    description = "WHOIS registration data, ASN lookup, IP ranges via BGPView"
    category = "recon"
    tools_required = ["whois"]
    input_schema  = {"target": "str — root domain"}
    output_schema = {"findings": "WHOIS data, ASN, IP ranges", "files": {"whois.json": "parsed data"}}
    tags = ["recon", "whois", "asn", "phase1"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        data = {}

        # ── WHOIS ────────────────────────────────────────────────────────────
        raw_whois = self._run_tool(f"whois {target} 2>/dev/null", timeout=20)
        if raw_whois:
            parsed = self._parse_whois(raw_whois)
            data["whois"] = parsed
            (out / "whois_raw.txt").write_text(raw_whois)

            result.add_finding("whois_registrar",  parsed.get("registrar", "unknown"),  severity="info")
            result.add_finding("whois_created",    parsed.get("created", "unknown"),    severity="info")
            result.add_finding("whois_expires",    parsed.get("expires", "unknown"),    severity="info")
            result.add_finding("whois_nameservers",", ".join(parsed.get("nameservers", [])), severity="info")

            # Flag privacy-protected registrations
            org = parsed.get("org", "").lower()
            if any(kw in org for kw in ["privacy", "proxy", "redacted", "whoisguard"]):
                result.add_finding(
                    finding_type="whois_privacy_protected",
                    value=parsed.get("org", ""),
                    severity="info",
                    notes="Registrant hidden behind privacy service"
                )
            else:
                result.add_finding("whois_org", parsed.get("org", "unknown"), severity="info",
                                   notes="Registrant org exposed — useful for scope expansion")

        # ── ASN lookup via BGPView API ────────────────────────────────────────
        try:
            resp = requests.get(
                f"https://api.bgpview.io/search?query_term={target}",
                timeout=10,
                headers={"User-Agent": "SpondonFW/1.0"}
            )
            if resp.status_code == 200:
                bgp = resp.json().get("data", {})
                asns = bgp.get("asns", [])
                for asn_info in asns[:5]:
                    asn = asn_info.get("asn", "")
                    name = asn_info.get("name", "")
                    result.add_finding(
                        finding_type="asn",
                        value=f"AS{asn} — {name}",
                        severity="info",
                        notes="Use for IP range discovery"
                    )
                    data.setdefault("asns", []).append({"asn": asn, "name": name})

                    # Get IP prefixes for this ASN
                    prefixes = self._get_asn_prefixes(asn)
                    for prefix in prefixes:
                        result.add_finding(
                            finding_type="ip_range",
                            value=prefix,
                            severity="info",
                            notes=f"IP range owned by AS{asn}"
                        )
                    data.setdefault("ip_ranges", []).extend(prefixes)

        except Exception as e:
            self.logger.warning(f"BGPView lookup failed: {e}")

        # Save combined output
        (out / "whois.json").write_text(json.dumps(data, indent=2))

        # Save IP ranges to flat file for use by other modules
        if data.get("ip_ranges"):
            (out / "ip_ranges.txt").write_text("\n".join(data["ip_ranges"]))

        result.metadata = {
            "asns_found": len(data.get("asns", [])),
            "ip_ranges_found": len(data.get("ip_ranges", [])),
        }
        result.finished_at = time.time()
        return result

    def _parse_whois(self, raw: str) -> Dict:
        def extract(patterns, text):
            for pat in patterns:
                m = re.search(pat, text, re.IGNORECASE)
                if m:
                    return m.group(1).strip()
            return ""

        return {
            "registrar":   extract([r"Registrar:\s*(.+)", r"registrar:\s*(.+)"], raw),
            "created":     extract([r"Creation Date:\s*(.+)", r"created:\s*(.+)", r"Registered on:\s*(.+)"], raw),
            "expires":     extract([r"Registry Expiry Date:\s*(.+)", r"expiry date:\s*(.+)", r"Expiry Date:\s*(.+)"], raw),
            "updated":     extract([r"Updated Date:\s*(.+)", r"last-modified:\s*(.+)"], raw),
            "org":         extract([r"Registrant Organization:\s*(.+)", r"org-name:\s*(.+)", r"Organisation:\s*(.+)"], raw),
            "country":     extract([r"Registrant Country:\s*(.+)", r"country:\s*(.+)"], raw),
            "nameservers": re.findall(r"Name Server:\s*(.+)", raw, re.IGNORECASE),
            "status":      re.findall(r"Domain Status:\s*(.+)", raw, re.IGNORECASE),
        }

    def _get_asn_prefixes(self, asn: str) -> List[str]:
        try:
            resp = requests.get(
                f"https://api.bgpview.io/asn/{asn}/prefixes",
                timeout=10,
                headers={"User-Agent": "SpondonFW/1.0"}
            )
            if resp.status_code == 200:
                data = resp.json().get("data", {})
                v4 = [p["prefix"] for p in data.get("ipv4_prefixes", [])[:20]]
                return v4
        except Exception:
            pass
        return []
