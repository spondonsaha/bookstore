"""
SpondonFW - Enumeration Module: Web Crawler
Spiders all live hosts with katana/hakrawler.
Collects URLs, forms, JS links, and API endpoints.
"""
import json
import time
from pathlib import Path
from typing import Dict, Set

from core.engine.base_module import BaseModule, ModuleResult


class WebCrawler(BaseModule):
    name = "enum.webcrawl"
    description = "Spider live hosts with katana — collect URLs, forms, and JS links"
    category = "enumeration"
    tools_required = ["katana", "hakrawler"]
    input_schema  = {"target": "str", "depth": "int (default 3)", "threads": "int (default 20)"}
    output_schema = {"findings": "Crawled URLs and forms", "files": {"crawled_urls.txt": "all URLs"}}
    tags = ["enumeration", "crawl", "phase2"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        depth   = ctx.get("depth", 3)
        threads = ctx.get("threads", 20)
        urls: Set[str] = set()

        # Get live hosts from previous recon stage if available
        live_hosts_file = self._find_live_hosts(ctx)

        # ── katana ───────────────────────────────────────────────────────────
        if self._tool_available("katana"):
            if live_hosts_file:
                cmd = (f"katana -list {live_hosts_file} -silent -depth {depth} "
                       f"-js-crawl -concurrency {threads} -no-color 2>/dev/null")
            else:
                cmd = (f"katana -u https://{target} -silent -depth {depth} "
                       f"-js-crawl -concurrency {threads} -no-color 2>/dev/null")
            raw = self._run_tool(cmd, timeout=900)
            for line in raw.splitlines():
                line = line.strip()
                if line.startswith("http"):
                    urls.add(line)
            self.logger.info(f"  katana: {len(urls)} URLs")

        # ── hakrawler fallback ───────────────────────────────────────────────
        elif self._tool_available("hakrawler"):
            raw = self._run_tool(
                f"echo https://{target} | hakrawler -depth {depth} -subs 2>/dev/null",
                timeout=300
            )
            for line in raw.splitlines():
                line = line.strip()
                if line.startswith("http"):
                    urls.add(line)
            self.logger.info(f"  hakrawler: {len(urls)} URLs")

        else:
            self.logger.warning("Neither katana nor hakrawler found — install one")

        self._write_lines(str(out / "crawled_urls.txt"), sorted(urls))

        for url in list(urls)[:500]:
            result.add_finding("crawled_url", url, severity="info")

        result.metadata = {"urls_crawled": len(urls),
                           "output_files": {"crawled_urls": str(out / "crawled_urls.txt")}}
        result.finished_at = time.time()
        return result

    def _find_live_hosts(self, ctx: Dict) -> str:
        prev = ctx.get("previous_results", {})
        for _, res in prev.items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("live_subdomains", "")
                if f and Path(f).exists():
                    return f
        return ""
