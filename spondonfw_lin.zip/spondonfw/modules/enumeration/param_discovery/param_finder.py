"""
SpondonFW - Enumeration Module: Parameter Discovery
Uses arjun + gf patterns to find hidden GET/POST parameters.
"""
import time
import json
from pathlib import Path
from typing import Dict, Set

from core.engine.base_module import BaseModule, ModuleResult


GF_PATTERNS = ["xss", "sqli", "ssrf", "redirect", "rce", "idor", "lfi", "debug-pages", "img-traversal"]


class ParamFinder(BaseModule):
    name = "enum.params"
    description = "Hidden parameter discovery with arjun + gf pattern filtering"
    category = "enumeration"
    tools_required = ["arjun", "gf"]
    input_schema  = {"target": "str", "urls_file": "str (optional)"}
    output_schema = {"findings": "Discovered parameters", "files": {"params.txt": "all params"}}
    tags = ["enumeration", "params", "phase2"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        urls_file = ctx.get("urls_file") or self._find_urls_file(ctx)
        all_params: Set[str] = set()

        # ── arjun parameter brute-force ──────────────────────────────────────
        if self._tool_available("arjun"):
            if urls_file and Path(urls_file).exists():
                arjun_out = str(out / "arjun_results.json")
                raw = self._run_tool(
                    f"arjun -i {urls_file} -oJ {arjun_out} --quiet 2>/dev/null",
                    timeout=600
                )
                if Path(arjun_out).exists():
                    try:
                        data = json.loads(Path(arjun_out).read_text())
                        for url_data in data:
                            for param in url_data.get("params", []):
                                all_params.add(f"{url_data.get('url','')}?{param}=FUZZ")
                    except Exception:
                        pass
            else:
                raw = self._run_tool(
                    f"arjun -u https://{target} --quiet 2>/dev/null", timeout=300
                )
                for line in raw.splitlines():
                    if "?" in line and "=" in line:
                        all_params.add(line.strip())
        else:
            self.logger.warning("arjun not found — install: pip install arjun")

        # ── gf pattern extraction from crawled URLs ──────────────────────────
        if self._tool_available("gf") and urls_file and Path(urls_file).exists():
            for pattern in GF_PATTERNS:
                raw = self._run_tool(f"gf {pattern} {urls_file} 2>/dev/null", timeout=30)
                for line in raw.splitlines():
                    line = line.strip()
                    if line:
                        all_params.add(line)
                        result.add_finding(
                            finding_type=f"param_gf_{pattern}",
                            value=line,
                            severity="medium" if pattern in ("sqli","ssrf","rce","lfi") else "low",
                            url=line,
                            notes=f"gf pattern: {pattern}"
                        )

        self._write_lines(str(out / "params.txt"), sorted(all_params))

        for p in list(all_params)[:200]:
            result.add_finding("parameter", p, severity="info")

        result.metadata = {"params_found": len(all_params),
                           "output_files": {"params": str(out / "params.txt")}}
        result.finished_at = time.time()
        return result

    def _find_urls_file(self, ctx: Dict) -> str:
        prev = ctx.get("previous_results", {})
        for _, res in prev.items():
            if hasattr(res, "metadata"):
                for key in ("crawled_urls", "all_urls", "wayback_urls"):
                    f = res.metadata.get("output_files", {}).get(key, "")
                    if f and Path(f).exists():
                        return f
        return ""
