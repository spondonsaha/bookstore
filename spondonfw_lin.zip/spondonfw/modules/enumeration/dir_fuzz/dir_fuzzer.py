"""
SpondonFW - Enumeration Module: Directory Fuzzer
Runs ffuf/feroxbuster against all live hosts.
"""
import time
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class DirFuzzer(BaseModule):
    name = "enum.dirfuzz"
    description = "Directory and path fuzzing with ffuf/feroxbuster"
    category = "enumeration"
    tools_required = ["ffuf", "feroxbuster"]
    input_schema = {"target": "str", "wordlist": "str", "threads": "int", "extensions": "str"}
    output_schema = {"findings": "Discovered paths", "files": {"dir_results.txt": "all results"}}
    tags = ["enumeration", "fuzzing", "phase2"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        wordlist   = ctx.get("wordlist", "/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt")
        threads    = ctx.get("threads", 40)
        extensions = ctx.get("extensions", "php,asp,aspx,jsp,json,txt,bak")
        filter_codes = ctx.get("filter_codes", "404,302")

        live_hosts = self._get_live_hosts(ctx, target)
        results_file = str(out / "dir_results.txt")

        for host in live_hosts[:20]:  # cap at 20 hosts
            host = host.strip()
            if not host:
                continue
            if not host.startswith("http"):
                host = f"https://{host}"

            if self._tool_available("ffuf") and Path(wordlist).exists():
                raw = self._run_tool(
                    f"ffuf -u {host}/FUZZ -w {wordlist} "
                    f"-e {extensions} -t {threads} "
                    f"-fc {filter_codes} -mc all "
                    f"-o {out}/ffuf_{host.replace('/','_').replace(':','')}.json "
                    f"-of json -s 2>/dev/null",
                    timeout=600
                )
            elif self._tool_available("feroxbuster") and Path(wordlist).exists():
                raw = self._run_tool(
                    f"feroxbuster -u {host} -w {wordlist} "
                    f"-x {extensions} -t {threads} "
                    f"--filter-status {filter_codes} -q "
                    f"-o {out}/ferox_{host.replace('/','_').replace(':','')}.txt 2>/dev/null",
                    timeout=600
                )

        # Aggregate all results
        all_found = []
        for f in out.glob("ffuf_*.json"):
            try:
                import json
                data = json.loads(f.read_text())
                for r in data.get("results", []):
                    url = r.get("url", "")
                    status = r.get("status", 0)
                    length = r.get("length", 0)
                    if url:
                        all_found.append(f"{status} {length} {url}")
                        sev = "high" if any(kw in url for kw in ["admin","backup","config",".git",".env"]) else "info"
                        result.add_finding("discovered_path", url, severity=sev,
                                           url=url, evidence=f"Status: {status}, Size: {length}")
            except Exception:
                continue

        for f in out.glob("ferox_*.txt"):
            for line in self._read_lines(str(f)):
                if line and not line.startswith("#"):
                    all_found.append(line)
                    parts = line.split()
                    url = parts[-1] if parts else ""
                    result.add_finding("discovered_path", url, severity="info", url=url)

        self._write_lines(results_file, all_found)
        result.metadata = {"paths_found": len(all_found)}
        result.finished_at = time.time()
        return result

    def _get_live_hosts(self, ctx: Dict, target: str):
        prev = ctx.get("previous_results", {})
        for _, res in prev.items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("live_subdomains", "")
                if f and Path(f).exists():
                    return self._read_lines(f)
        return [f"https://{target}"]
