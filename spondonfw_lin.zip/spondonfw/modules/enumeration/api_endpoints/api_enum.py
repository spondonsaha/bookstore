"""SpondonFW - API Endpoint Enumerator"""
import time, json, requests
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class APIEnumerator(BaseModule):
    name = "enum.api_endpoints"
    description = "OpenAPI spec hunting, GraphQL introspection, REST verb testing"
    category = "enumeration"
    tools_required = ["nuclei"]
    input_schema = {"target": "str"}
    output_schema = {"findings": "API endpoints and specs", "files": {"api_endpoints.json": "results"}}
    tags = ["enumeration", "api", "graphql", "phase2"]

    SPEC_PATHS = ["/swagger.json", "/swagger/v1/swagger.json", "/openapi.json",
                  "/api/swagger.json", "/api-docs", "/v1/api-docs", "/v2/api-docs",
                  "/api/openapi.yaml", "/.well-known/openapi.yaml"]
    GRAPHQL_PATHS = ["/graphql", "/api/graphql", "/v1/graphql", "/query", "/gql"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": "SpondonFW/1.0"}
        found = []

        base = f"https://{target}"

        # Swagger / OpenAPI
        for path in self.SPEC_PATHS:
            try:
                r = requests.get(base + path, headers=headers, timeout=8, verify=False)
                if r.status_code == 200 and len(r.text) > 100:
                    result.add_finding("openapi_spec", base + path, severity="medium",
                                       url=base + path, notes="OpenAPI/Swagger spec exposed")
                    found.append({"type": "openapi", "url": base + path})
                    # Extract endpoints from spec
                    try:
                        spec = r.json()
                        for ep_path in spec.get("paths", {}).keys():
                            result.add_finding("api_endpoint", ep_path, severity="info",
                                               url=base + ep_path, notes="From OpenAPI spec")
                    except Exception:
                        pass
            except Exception:
                continue

        # GraphQL introspection
        for path in self.GRAPHQL_PATHS:
            try:
                r = requests.post(base + path,
                                  json={"query": "{__schema{types{name}}}"},
                                  headers={**headers, "Content-Type": "application/json"},
                                  timeout=8, verify=False)
                if r.status_code == 200 and "__schema" in r.text:
                    result.add_finding("graphql_introspection", base + path, severity="medium",
                                       url=base + path,
                                       notes="GraphQL introspection enabled — schema exposed")
                    found.append({"type": "graphql", "url": base + path})
            except Exception:
                continue

        # nuclei API templates
        if self._tool_available("nuclei"):
            nout = str(out / "nuclei_api.txt")
            self._run_tool(f"nuclei -u {base} -t exposures/apis/ -silent -o {nout} 2>/dev/null", timeout=300)
            for line in self._read_lines(nout):
                result.add_finding("nuclei_api", line, severity="medium", evidence=line)

        (out / "api_endpoints.json").write_text(json.dumps(found, indent=2))
        result.metadata = {"endpoints_found": len(found)}
        result.finished_at = time.time()
        return result
