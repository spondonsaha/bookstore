"""SpondonFW - vuln.auth"""
import time, requests, base64, json
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class AuthTester(BaseModule):
    name = "vuln.auth"
    description = "JWT weaknesses, OAuth misconfigs, default credentials, brute logic"
    category = "vulnscan"
    tools_required = ["nuclei"]
    input_schema = {"target": "str"}
    output_schema = {"findings": "Auth vulnerabilities"}
    tags = ["auth", "jwt", "oauth", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        base = f"https://{target}"
        headers = {"User-Agent": "SpondonFW/1.0"}

        # nuclei auth templates
        if self._tool_available("nuclei"):
            nout = str(out / "nuclei_auth.txt")
            self._run_tool(
                f"nuclei -u {base} "
                f"-t vulnerabilities/generic/ "
                f"-t default-logins/ "
                f"-t exposures/tokens/ "
                f"-silent -o {nout} 2>/dev/null",
                timeout=300
            )
            for line in self._read_lines(nout):
                result.add_finding("auth_nuclei", line, severity="high", evidence=line)

        # Check for common OAuth endpoints
        oauth_paths = ["/oauth/authorize", "/oauth/token", "/.well-known/openid-configuration",
                       "/auth/callback", "/login/oauth/callback"]
        for path in oauth_paths:
            try:
                r = requests.get(base + path, headers=headers, timeout=8, verify=False,
                                 allow_redirects=False)
                if r.status_code in (200, 302, 400):
                    result.add_finding(
                        finding_type="oauth_endpoint",
                        value=base + path,
                        severity="medium",
                        url=base + path,
                        notes="Test for state param bypass, redirect_uri manipulation, token leakage"
                    )
            except Exception:
                continue

        # Check for JWT in cookies/headers from any previous crawl output
        crawl_file = self._find_crawl_output(ctx)
        if crawl_file and Path(crawl_file).exists():
            for line in self._read_lines(crawl_file)[:1000]:
                import re
                jwt_pattern = r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*'
                for jwt in re.findall(jwt_pattern, line):
                    self._analyse_jwt(jwt, line, result)

        result.finished_at = time.time()
        return result

    def _analyse_jwt(self, token: str, source: str, result: ModuleResult):
        try:
            parts = token.split(".")
            header = json.loads(base64.b64decode(parts[0] + "==").decode())
            alg = header.get("alg", "")
            if alg.lower() == "none":
                result.add_finding("jwt_alg_none", token[:40] + "...", severity="critical",
                                   evidence=f"Algorithm: none", notes="JWT accepts alg:none — authentication bypass")
            elif alg.upper() in ("HS256", "HS384", "HS512"):
                result.add_finding("jwt_weak_alg", token[:40] + "...", severity="medium",
                                   evidence=f"Algorithm: {alg}",
                                   notes="Symmetric JWT — test for weak secret with jwt-tool or hashcat")
        except Exception:
            pass

    def _find_crawl_output(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("crawled_urls", "")
                if f and Path(f).exists():
                    return f
        return ""
