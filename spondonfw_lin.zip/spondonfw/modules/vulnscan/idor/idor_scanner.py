"""SpondonFW - vuln.idor"""
import time, re
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class IDORScanner(BaseModule):
    name = "vuln.idor"
    description = "IDOR detection: numeric ID enumeration and horizontal privilege escalation hints"
    category = "vulnscan"
    tools_required = []
    input_schema = {"target": "str"}
    output_schema = {"findings": "IDOR candidates"}
    tags = ["idor", "phase3"]

    IDOR_PARAMS = ["id","user_id","account","uid","userid","profile","order","invoice",
                   "ticket","document","file","record","object","item","resource"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        urls_file = self._find_param_urls(ctx)
        if not urls_file:
            result.add_finding("idor_skipped", "No URL file — run enum.params first", severity="info")
            result.finished_at = time.time()
            return result

        for url in self._read_lines(urls_file)[:500]:
            # Flag URLs with numeric ID-like parameters
            for param in self.IDOR_PARAMS:
                pattern = rf"[?&]{param}=(\d+)"
                m = re.search(pattern, url, re.IGNORECASE)
                if m:
                    val = int(m.group(1))
                    result.add_finding(
                        finding_type="idor_candidate",
                        value=url,
                        severity="high",
                        url=url,
                        evidence=f"Param '{param}' = {val}",
                        notes=f"Test by changing {param} to {val-1}, {val+1}, other user IDs"
                    )
                    break

            # Flag UUID-style params
            uuid_pattern = r"[?&]\w+=([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
            if re.search(uuid_pattern, url, re.IGNORECASE):
                result.add_finding("idor_uuid_candidate", url, severity="medium",
                                   url=url, notes="UUID-based reference — test for predictability")

        result.finished_at = time.time()
        return result

    def _find_param_urls(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("params", "")
                if f and Path(f).exists():
                    return f
        return ""
