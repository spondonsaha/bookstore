"""SpondonFW - vuln.open_redirect"""
import time, requests, re
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

REDIRECT_PARAMS = ["url","redirect","next","return","returnurl","dest","destination",
                   "redir","goto","continue","target","ref","out","view","to","link"]
PAYLOADS = ["https://evil.com", "//evil.com", "/\\evil.com", "https:evil.com",
            "%2F%2Fevil.com", "///evil.com", "https://evil.com%23"]

class OpenRedirectScanner(BaseModule):
    name = "vuln.open_redirect"
    description = "Open redirect detection in URL redirect parameters"
    category = "vulnscan"
    tools_required = ["nuclei"]
    input_schema = {"target": "str"}
    output_schema = {"findings": "Open redirect vulnerabilities"}
    tags = ["open-redirect", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": "SpondonFW/1.0"}

        if self._tool_available("nuclei"):
            nout = str(out / "nuclei_redirect.txt")
            self._run_tool(
                f"nuclei -u https://{target} -t vulnerabilities/redirect/ "
                f"-silent -o {nout} 2>/dev/null", timeout=300
            )
            for line in self._read_lines(nout):
                result.add_finding("open_redirect_nuclei", line, severity="medium", evidence=line)

        urls_file = self._find_param_urls(ctx)
        if urls_file and Path(urls_file).exists():
            for url in self._read_lines(urls_file)[:300]:
                parsed = urlparse(url)
                params = parse_qs(parsed.query)
                for param in params:
                    if param.lower() in REDIRECT_PARAMS:
                        for payload in PAYLOADS[:3]:
                            test_params = dict(params)
                            test_params[param] = [payload]
                            test_url = urlunparse(parsed._replace(query=urlencode(test_params, doseq=True)))
                            try:
                                r = requests.get(test_url, headers=headers, timeout=5,
                                                 verify=False, allow_redirects=False)
                                loc = r.headers.get("Location", "")
                                if "evil.com" in loc:
                                    result.add_finding("open_redirect", test_url, severity="medium",
                                        url=test_url, evidence=f"Location: {loc}",
                                        notes=f"Param: {param} redirects to attacker domain")
                                    break
                            except Exception:
                                continue

        result.finished_at = time.time()
        return result

    def _find_param_urls(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("params", "")
                if f and Path(f).exists():
                    return f
        return ""
