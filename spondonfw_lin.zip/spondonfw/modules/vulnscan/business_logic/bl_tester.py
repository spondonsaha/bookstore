"""SpondonFW - vuln.business_logic"""
import time, re
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class BusinessLogicTester(BaseModule):
    name = "vuln.business_logic"
    description = "Flag workflows for manual review: race conditions, price manipulation, priv escalation"
    category = "vulnscan"
    tools_required = []
    input_schema = {"target": "str"}
    output_schema = {"findings": "Business logic candidates for manual review"}
    tags = ["business-logic", "race-condition", "phase3"]

    RACE_KEYWORDS   = ["transfer", "withdraw", "purchase", "checkout", "coupon", "redeem",
                       "apply", "claim", "vote", "like", "referral", "bonus"]
    PRICE_KEYWORDS  = ["price", "amount", "total", "cost", "quantity", "qty", "discount",
                       "promo", "coupon", "credit", "balance"]
    PRIV_KEYWORDS   = ["role", "admin", "permission", "privilege", "level", "tier",
                       "isadmin", "is_admin", "type", "group"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        urls_file = self._find_urls(ctx)
        if not urls_file:
            result.add_finding("bl_skipped", "No URL file available", severity="info")
            result.finished_at = time.time()
            return result

        for url in self._read_lines(urls_file)[:1000]:
            url_lower = url.lower()

            if any(kw in url_lower for kw in self.RACE_KEYWORDS):
                result.add_finding("race_condition_candidate", url, severity="medium", url=url,
                    notes="Test with Turbo Intruder single-packet attack for race condition")

            if any(kw in url_lower for kw in self.PRICE_KEYWORDS):
                result.add_finding("price_manipulation_candidate", url, severity="medium", url=url,
                    notes="Test negative values, zero, extremely large/small numbers, currency symbols")

            if any(kw in url_lower for kw in self.PRIV_KEYWORDS):
                result.add_finding("privilege_param_candidate", url, severity="high", url=url,
                    notes="Role/permission param exposed in URL — test for manipulation")

        result.finished_at = time.time()
        return result

    def _find_urls(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                for key in ("params", "crawled_urls", "all_urls"):
                    f = res.metadata.get("output_files", {}).get(key, "")
                    if f and Path(f).exists():
                        return f
        return ""
