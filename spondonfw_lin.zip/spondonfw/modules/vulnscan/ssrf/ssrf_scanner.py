"""SpondonFW - vuln.ssrf"""
import time, requests, re
from pathlib import Path
from typing import Dict, List
from core.engine.base_module import BaseModule, ModuleResult

SSRF_PARAMS = ["url","redirect","next","dest","destination","redir","return","returnurl",
               "callback","goto","image","img","src","feed","host","site","path","continue",
               "data","domain","window","reference","link","out","view","dir","show","navigation"]

SSRF_PAYLOADS = [
    "http://169.254.169.254/latest/meta-data/",
    "http://metadata.google.internal/computeMetadata/v1/",
    "http://169.254.170.2/v2/metadata",
    "http://localhost/",
    "http://127.0.0.1/",
    "http://[::1]/",
]

class SSRFScanner(BaseModule):
    name = "vuln.ssrf"
    description = "SSRF detection via URL params, Referer, Host header injection"
    category = "vulnscan"
    tools_required = ["nuclei"]
    input_schema = {"target": "str", "urls_file": "str (optional)"}
    output_schema = {"findings": "SSRF candidates"}
    tags = ["ssrf", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": "SpondonFW/1.0"}

        # nuclei SSRF templates
        if self._tool_available("nuclei"):
            nout = str(out / "nuclei_ssrf.txt")
            self._run_tool(
                f"nuclei -u https://{target} -t vulnerabilities/ssrf/ "
                f"-t fuzzing/ssrf/ -silent -o {nout} 2>/dev/null", timeout=300
            )
            for line in self._read_lines(nout):
                result.add_finding("ssrf_nuclei", line, severity="high", evidence=line)

        # Manual probe — check for SSRF-prone params in crawled URLs
        urls_file = ctx.get("urls_file") or self._find_param_urls(ctx)
        if urls_file and Path(urls_file).exists():
            from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
            for url in self._read_lines(urls_file)[:200]:
                parsed = urlparse(url)
                params = parse_qs(parsed.query)
                for param in params:
                    if param.lower() in SSRF_PARAMS:
                        result.add_finding(
                            finding_type="ssrf_candidate",
                            value=url,
                            severity="medium",
                            url=url,
                            notes=f"SSRF-prone parameter: {param} — test manually with Interactsh"
                        )

        result.finished_at = time.time()
        return result

    def _find_param_urls(self, ctx):
        for _, res in ctx.get("previous_results", {}).items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("params", "")
                if f and Path(f).exists():
                    return f
        return ""
