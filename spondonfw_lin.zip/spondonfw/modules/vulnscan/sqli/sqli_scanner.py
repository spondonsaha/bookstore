"""SpondonFW - vuln.sqli"""
import time
from pathlib import Path
from typing import Dict
from core.engine.base_module import BaseModule, ModuleResult

class SQLiScanner(BaseModule):
    name = "vuln.sqli"
    description = "SQL injection detection with sqlmap on all parameterised URLs"
    category = "vulnscan"
    tools_required = ["sqlmap"]
    input_schema = {"target": "str", "level": "int (1-5)", "risk": "int (1-3)", "techniques": "str"}
    output_schema = {"findings": "Confirmed SQLi points"}
    tags = ["sqli", "injection", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        level      = ctx.get("level", 3)
        risk       = ctx.get("risk", 2)
        techniques = ctx.get("techniques", "BEUSTQ")
        urls_file  = self._find_param_urls(ctx)

        if not self._tool_available("sqlmap"):
            result.add_finding("sqli_skipped", "sqlmap not installed", severity="info",
                               notes="Install: sudo apt install sqlmap  OR  pip install sqlmap")
            result.finished_at = time.time()
            return result

        if not urls_file:
            result.add_finding("sqli_skipped", "No parameterised URL file found — run enum.params first",
                               severity="info")
            result.finished_at = time.time()
            return result

        sqlmap_out = str(out / "sqlmap_results")
        self._run_tool(
            f"sqlmap -m {urls_file} --level={level} --risk={risk} "
            f"--technique={techniques} --batch --random-agent "
            f"--output-dir={sqlmap_out} 2>/dev/null",
            timeout=3600
        )

        # Parse results directory for confirmed injections
        for log_file in Path(sqlmap_out).rglob("*.log"):
            for line in self._read_lines(str(log_file)):
                if "is vulnerable" in line.lower() or "injection" in line.lower():
                    result.add_finding("sqli_confirmed", line.strip(), severity="critical",
                                       evidence=line, notes="Confirmed by sqlmap")

        result.finished_at = time.time()
        return result

    def _find_param_urls(self, ctx: Dict) -> str:
        prev = ctx.get("previous_results", {})
        for _, res in prev.items():
            if hasattr(res, "metadata"):
                f = res.metadata.get("output_files", {}).get("params", "")
                if f and Path(f).exists():
                    return f
        return ""
