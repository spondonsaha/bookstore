"""
SpondonFW - Utility: KeyStore
Encrypted API key storage using keyring or fallback to config file.
"""
import json
import os
from pathlib import Path
from typing import Dict, List, Optional


class KeyStore:
    """
    Store and retrieve API keys.
    Priority: environment variables → keyring → ~/.spondonfw/keys.json (plain, warn)
    """
    KEYSTORE_PATH = Path.home() / ".spondonfw" / "keys.json"
    ENV_PREFIX = "SPONDONFW_KEY_"

    def __init__(self):
        self.KEYSTORE_PATH.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, str] = {}
        self._load()

    def _load(self):
        if self.KEYSTORE_PATH.exists():
            try:
                with open(self.KEYSTORE_PATH) as f:
                    self._data = json.load(f)
            except Exception:
                self._data = {}

    def _save(self):
        with open(self.KEYSTORE_PATH, "w") as f:
            json.dump(self._data, f, indent=2)
        os.chmod(self.KEYSTORE_PATH, 0o600)  # owner read/write only

    def get(self, service: str) -> Optional[str]:
        """Retrieve key: env var > keystore file"""
        env_key = f"{self.ENV_PREFIX}{service.upper()}"
        val = os.environ.get(env_key) or os.environ.get(service.upper())
        if val:
            return val
        return self._data.get(service.lower())

    def set(self, service: str, key: str):
        self._data[service.lower()] = key
        self._save()

    def delete(self, service: str):
        self._data.pop(service.lower(), None)
        self._save()

    def list(self) -> List[str]:
        return sorted(self._data.keys())
