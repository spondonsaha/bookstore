"""
SpondonFW - Utility: Rate Limiter
Token bucket rate limiter for HTTP requests.
"""
import time
import threading


class RateLimiter:
    """
    Token bucket rate limiter.
    Usage:
        rl = RateLimiter(rate=10)  # 10 req/sec
        with rl:
            requests.get(url)
    """
    def __init__(self, rate: float = 10.0):
        self.rate = rate
        self._lock = threading.Lock()
        self._tokens = rate
        self._last_check = time.monotonic()

    def _refill(self):
        now = time.monotonic()
        elapsed = now - self._last_check
        self._tokens = min(self.rate, self._tokens + elapsed * self.rate)
        self._last_check = now

    def acquire(self):
        with self._lock:
            self._refill()
            if self._tokens >= 1:
                self._tokens -= 1
                return
            wait = (1 - self._tokens) / self.rate
        time.sleep(wait)
        with self._lock:
            self._refill()
            self._tokens -= 1

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args):
        pass
