#!/usr/bin/env python3
"""
SpondonFW - Modular Bug Bounty / Pentesting Framework
CLI Entry Point
Author: Spondon Saha
"""

import click
import sys
import os
import json
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.pipeline.runner import PipelineRunner
from core.loader.module_loader import ModuleLoader
from core.engine.session import SessionManager
from utils.config_parser import ConfigParser
from utils.logger import get_logger

console = Console()
logger = get_logger(__name__)

BANNER = """
  ██████  ██████   ██████  ███    ██ ██████   ██████  ███    ██ ███████ ██     ██ 
 ██       ██   ██ ██    ██ ████   ██ ██   ██ ██    ██ ████   ██ ██      ██     ██ 
  ██████  ██████  ██    ██ ██ ██  ██ ██   ██ ██    ██ ██ ██  ██ █████   ██  █  ██ 
       ██ ██      ██    ██ ██  ██ ██ ██   ██ ██    ██ ██  ██ ██ ██      ██ ███ ██ 
  ██████  ██       ██████  ██   ████ ██████   ██████  ██   ████ ██       ███ ███  
                                                                                   
  [bold cyan]Bug Bounty Framework[/bold cyan] | [bold green]v1.0.0[/bold green] | [dim]by Spondon Saha[/dim]
"""


@click.group()
@click.option('--debug', is_flag=True, default=False, help='Enable debug logging')
@click.option('--config', '-c', default='config/default.yaml', help='Path to config file')
@click.pass_context
def cli(ctx, debug, config):
    """SpondonFW - Modular Pentesting & Bug Bounty Framework"""
    ctx.ensure_object(dict)
    ctx.obj['debug'] = debug
    ctx.obj['config'] = config

    if debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)

    console.print(BANNER)


# ─────────────────────────────────────────────
#  SCAN COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def scan():
    """Run scans against a target"""
    pass


@scan.command('full')
@click.option('--target', '-t', required=True, help='Target domain (e.g. example.com)')
@click.option('--pipeline', '-p', default='config/pipelines/full_scan.yaml', help='Pipeline config file')
@click.option('--output', '-o', default='results/', help='Output directory')
@click.option('--resume', is_flag=True, default=False, help='Resume previous scan session')
@click.option('--rate-limit', default=10, help='Requests per second (default: 10)')
@click.pass_context
def scan_full(ctx, target, pipeline, output, resume, rate_limit):
    """Run a full methodology pipeline against a target"""
    console.print(Panel(f"[bold green]Starting Full Scan[/bold green]\n"
                        f"Target: [cyan]{target}[/cyan]\n"
                        f"Pipeline: [yellow]{pipeline}[/yellow]\n"
                        f"Output: [blue]{output}[/blue]",
                        title="SpondonFW Scan"))

    runner = PipelineRunner(
        target=target,
        pipeline_config=pipeline,
        output_dir=output,
        resume=resume,
        rate_limit=rate_limit
    )
    runner.execute()


@scan.command('module')
@click.option('--target', '-t', required=True, help='Target domain')
@click.option('--module', '-m', required=True, help='Module to run (e.g. recon.subdomains)')
@click.option('--output', '-o', default='results/', help='Output directory')
@click.option('--args', '-a', default='{}', help='JSON string of module arguments')
@click.pass_context
def scan_module(ctx, target, module, output, args):
    """Run a single module against a target"""
    try:
        extra_args = json.loads(args)
    except json.JSONDecodeError:
        console.print("[red]Error: --args must be valid JSON[/red]")
        sys.exit(1)

    loader = ModuleLoader()
    mod = loader.load(module)

    console.print(f"[cyan]Running module:[/cyan] {module} → [yellow]{target}[/yellow]")
    result = mod.run(target=target, output_dir=output, **extra_args)
    console.print(f"[green]✓ Module complete.[/green] Results saved to {output}")


@scan.command('recon')
@click.option('--target', '-t', required=True, help='Target domain')
@click.option('--output', '-o', default='results/', help='Output directory')
@click.pass_context
def scan_recon(ctx, target, output):
    """Run only the recon phase"""
    runner = PipelineRunner(target=target, pipeline_config='config/pipelines/recon_only.yaml', output_dir=output)
    runner.execute()


@scan.command('enum')
@click.option('--target', '-t', required=True, help='Target domain')
@click.option('--subdomains', '-s', default=None, help='File with subdomains list')
@click.option('--output', '-o', default='results/', help='Output directory')
@click.pass_context
def scan_enum(ctx, target, subdomains, output):
    """Run only the enumeration phase"""
    runner = PipelineRunner(
        target=target,
        pipeline_config='config/pipelines/enum_only.yaml',
        output_dir=output,
        extra={'subdomains_file': subdomains}
    )
    runner.execute()


@scan.command('vulnscan')
@click.option('--target', '-t', required=True, help='Target domain or URL')
@click.option('--urls', '-u', default=None, help='File with URL list')
@click.option('--checks', default='all', help='Comma-separated vuln checks (xss,sqli,ssrf,idor,...) or "all"')
@click.option('--output', '-o', default='results/', help='Output directory')
@click.pass_context
def scan_vuln(ctx, target, urls, checks, output):
    """Run vulnerability scanning phase"""
    runner = PipelineRunner(
        target=target,
        pipeline_config='config/pipelines/vulnscan_only.yaml',
        output_dir=output,
        extra={'urls_file': urls, 'checks': checks}
    )
    runner.execute()


# ─────────────────────────────────────────────
#  SESSION COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def session():
    """Manage scan sessions"""
    pass


@session.command('list')
def session_list():
    """List all saved sessions"""
    sm = SessionManager()
    sessions = sm.list_sessions()
    if not sessions:
        console.print("[dim]No sessions found.[/dim]")
        return
    for s in sessions:
        console.print(f"[cyan]{s['id']}[/cyan]  {s['target']}  [{s['status']}]  {s['created_at']}")


@session.command('show')
@click.argument('session_id')
def session_show(session_id):
    """Show details of a specific session"""
    sm = SessionManager()
    sm.show(session_id)


@session.command('delete')
@click.argument('session_id')
def session_delete(session_id):
    """Delete a session"""
    sm = SessionManager()
    sm.delete(session_id)
    console.print(f"[red]Deleted session:[/red] {session_id}")


# ─────────────────────────────────────────────
#  MODULE COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def module():
    """List and inspect available modules"""
    pass


@module.command('list')
def module_list():
    """List all available modules"""
    loader = ModuleLoader()
    modules = loader.discover()
    for category, mods in modules.items():
        console.print(f"\n[bold yellow]{category.upper()}[/bold yellow]")
        for m in mods:
            console.print(f"  [cyan]{m['name']}[/cyan]  -  {m['description']}")


@module.command('info')
@click.argument('module_path')
def module_info(module_path):
    """Show info about a specific module"""
    loader = ModuleLoader()
    mod = loader.load(module_path)
    console.print(Panel(
        f"[bold]{mod.name}[/bold]\n\n"
        f"Description: {mod.description}\n"
        f"Input:  {mod.input_schema}\n"
        f"Output: {mod.output_schema}\n"
        f"Tools:  {', '.join(mod.tools_required)}",
        title=f"Module: {module_path}"
    ))


# ─────────────────────────────────────────────
#  REPORT COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def report():
    """Generate and manage reports"""
    pass


@report.command('generate')
@click.option('--session', '-s', required=True, help='Session ID to report on')
@click.option('--format', '-f', default='html', type=click.Choice(['html', 'markdown', 'json', 'pdf']), help='Output format')
@click.option('--output', '-o', default='reports/', help='Output directory')
def report_generate(session, format, output):
    """Generate a report from a completed session"""
    from modules.reporting.report_engine import ReportEngine
    engine = ReportEngine(session_id=session, output_dir=output)
    path = engine.generate(fmt=format)
    console.print(f"[green]Report generated:[/green] {path}")


# ─────────────────────────────────────────────
#  CONFIG COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def config():
    """Manage framework configuration"""
    pass


@config.command('init')
@click.option('--output', '-o', default='config/user.yaml', help='Output config file path')
def config_init(output):
    """Initialize a new user configuration file"""
    ConfigParser.scaffold(output)
    console.print(f"[green]Config scaffolded:[/green] {output}")


@config.command('set-key')
@click.argument('service')
@click.argument('key')
def config_set_key(service, key):
    """Store an API key for a service (e.g. shodan, github)"""
    from utils.keystore import KeyStore
    ks = KeyStore()
    ks.set(service, key)
    console.print(f"[green]API key set for:[/green] {service}")


@config.command('list-keys')
def config_list_keys():
    """List all stored API key services"""
    from utils.keystore import KeyStore
    ks = KeyStore()
    keys = ks.list()
    for k in keys:
        console.print(f"  [cyan]{k}[/cyan]  [dim](stored)[/dim]")


# ─────────────────────────────────────────────
#  PLUGIN COMMANDS
# ─────────────────────────────────────────────

@cli.group()
def plugin():
    """Manage plugins"""
    pass


@plugin.command('list')
def plugin_list():
    """List installed plugins"""
    from core.loader.plugin_loader import PluginLoader
    pl = PluginLoader()
    for p in pl.list():
        console.print(f"  [magenta]{p['name']}[/magenta]  v{p['version']}  -  {p['description']}")


@plugin.command('install')
@click.argument('path_or_url')
def plugin_install(path_or_url):
    """Install a plugin from path or git URL"""
    from core.loader.plugin_loader import PluginLoader
    pl = PluginLoader()
    pl.install(path_or_url)
    console.print(f"[green]Plugin installed:[/green] {path_or_url}")


if __name__ == '__main__':
    cli(obj={})
