# ⚡ SpondonFW — Modular Bug Bounty & Pentesting Framework

> Built on Spondon Saha's personal methodology. Modular, pipeline-driven,
> extensible with plugins, and designed to scale from single targets to full
> bug bounty programme automation.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Folder Structure](#folder-structure)
3. [Tech Stack & Rationale](#tech-stack--rationale)
4. [Module Breakdown](#module-breakdown)
5. [Pipeline System](#pipeline-system)
6. [Installation](#installation)
7. [CLI Usage](#cli-usage)
8. [Plugin System](#plugin-system)
9. [API Key Management](#api-key-management)
10. [Improvements over Ars0n Framework](#improvements-over-ars0n-framework)
11. [Roadmap](#roadmap)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        CLI Layer                            │
│   spondonfw scan full | scan module | report | session      │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                  Pipeline Runner                            │
│  Reads YAML config → resolves deps → executes stages        │
│  Checkpointing · Resume · Condition evaluation              │
└────────────┬──────────────────────────┬─────────────────────┘
             │                          │
             ▼                          ▼
┌────────────────────┐    ┌─────────────────────────────────┐
│   Module Loader    │    │         Session Manager         │
│  Registry-based    │    │  Create / Resume / List / Show  │
│  + Plugin support  │    └─────────────────────────────────┘
└────────┬───────────┘
         │ loads
         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Module Layer                              │
│                                                             │
│  Phase 1: RECON                                             │
│  ├── recon.subdomains   (crt.sh, subfinder, amass, puredns) │
│  ├── recon.dns          (zone xfer, DNSSEC, MX/SPF)         │
│  ├── recon.whois        (WHOIS, ASN, IP ranges)             │
│  ├── recon.shodan       (exposed ports, banners)            │
│  ├── recon.github       (dorking, secret leaks)             │
│  └── recon.wayback      (historical URLs, gau)              │
│                                                             │
│  Phase 2: ENUMERATION                                       │
│  ├── enum.webcrawl      (katana, depth spider)              │
│  ├── enum.js_analysis   (endpoints, secrets from JS)        │
│  ├── enum.params        (arjun, gf patterns)                │
│  ├── enum.dirfuzz       (ffuf, feroxbuster)                 │
│  └── enum.api_endpoints (OpenAPI, GraphQL, REST verbs)      │
│                                                             │
│  Phase 3: VULN SCAN                                         │
│  ├── vuln.xss           (dalfox, DOM analysis, SSTI)        │
│  ├── vuln.sqli          (sqlmap, manual detection)          │
│  ├── vuln.ssrf          (Interactsh, header injection)      │
│  ├── vuln.idor          (ID enum, UUID guessing)            │
│  ├── vuln.auth          (JWT, OAuth, brute logic)           │
│  ├── vuln.business_logic(race cond., price manip.)          │
│  ├── vuln.open_redirect (param testing)                     │
│  └── vuln.lfi           (path traversal, LFI)              │
│                                                             │
│  Phase 4: REPORTING                                         │
│  └── reporting.html / .json / .markdown                     │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                  Data Layer                                 │
│  SQLite (default) · PostgreSQL · MongoDB                    │
│  Tables: results, findings (indexed by severity/target)     │
└─────────────────────────────────────────────────────────────┘
```

---

## Folder Structure

```
spondonfw/
│
├── cli/
│   └── main.py                  ← Click CLI entry point
│
├── core/
│   ├── engine/
│   │   ├── base_module.py       ← Abstract BaseModule all modules inherit
│   │   ├── session.py           ← Session persistence & resume
│   │   └── task_queue.py        ← (future) Celery/Redis task queue
│   ├── pipeline/
│   │   └── runner.py            ← Pipeline executor (dep resolution, checkpoints)
│   └── loader/
│       ├── module_loader.py     ← Dynamic module registry & import
│       └── plugin_loader.py     ← Plugin install/load system
│
├── modules/
│   ├── recon/
│   │   ├── subdomains/subdomain_enum.py
│   │   ├── dns/dns_recon.py
│   │   ├── whois/whois_lookup.py
│   │   ├── shodan/shodan_lookup.py
│   │   ├── github_dorking/github_dork.py
│   │   └── subdomains/wayback_urls.py
│   ├── enumeration/
│   │   ├── web_crawl/crawler.py
│   │   ├── js_analysis/js_analyzer.py
│   │   ├── param_discovery/param_finder.py
│   │   ├── dir_fuzz/dir_fuzzer.py
│   │   └── api_endpoints/api_enum.py
│   ├── vulnscan/
│   │   ├── xss/xss_scanner.py
│   │   ├── sqli/sqli_scanner.py
│   │   ├── ssrf/ssrf_scanner.py
│   │   ├── idor/idor_scanner.py
│   │   ├── auth/auth_tester.py
│   │   ├── business_logic/bl_tester.py
│   │   ├── open_redirect/or_scanner.py
│   │   └── lfi/lfi_scanner.py
│   └── reporting/
│       └── report_engine.py
│
├── config/
│   ├── default.yaml             ← Global framework defaults
│   ├── user.yaml                ← Your personal overrides
│   └── pipelines/
│       ├── full_scan.yaml       ← All 4 phases
│       ├── recon_only.yaml      ← Phase 1 only
│       ├── enum_only.yaml       ← Phase 2 only
│       └── vulnscan_only.yaml   ← Phase 3 only
│
├── db/
│   └── store.py                 ← SQLite abstraction layer
│
├── api/
│   └── server.py                ← (optional) REST API for GUI
│
├── plugins/                     ← Community/custom plugins live here
│
├── utils/
│   ├── config_parser.py
│   ├── logger.py
│   ├── rate_limiter.py
│   └── keystore.py
│
├── tests/
├── requirements.txt
├── setup.py
└── README.md
```

---

## Tech Stack & Rationale

| Component | Choice | Why |
|-----------|--------|-----|
| Language | **Python 3.9+** | Rich ecosystem of security tools (requests, scapy, etc.), readable, widely supported |
| CLI | **Click + Rich** | Declarative command groups, beautiful terminal output, colours and tables |
| Config | **YAML** | Human-editable, widely understood, supports inline comments |
| Database | **SQLite → PostgreSQL** | SQLite requires zero setup (perfect for solo use); swap to Postgres for team/hosted use |
| Task Queue | **Celery + Redis** *(optional)* | Distribute parallel scans across workers; Redis is lightweight |
| Frontend | **React + Vite** *(optional)* | Fast dashboard, easy to extend; consume the REST API |
| HTTP client | **requests + httpx** | Battle-tested; httpx for async when needed |
| Reporting | **Jinja2 HTML / Markdown** | Self-contained HTML reports, no server needed |

---

## Module Breakdown

### Phase 1 — Recon

| Module | Purpose | Tools | Output |
|--------|---------|-------|--------|
| `recon.subdomains` | Multi-layer subdomain discovery | subfinder, amass, puredns, crt.sh, assetfinder | `all_subdomains.txt`, `live_subdomains.txt`, `httpx_output.json` |
| `recon.dns` | Zone transfers, DNSSEC, MX/SPF/DMARC | dnsx, dig | `dns_records.json` |
| `recon.whois` | WHOIS, ASN, IP ranges, registrar | whois, bgpview API | `whois.json`, `asn_ranges.txt` |
| `recon.shodan` | Open ports, service banners | shodan-cli, Censys | `shodan_results.json` |
| `recon.github` | Public code, secret leaks | gh CLI, truffleHog | `github_secrets.json` |
| `recon.wayback` | Historical URLs, archived paths | waybackurls, gau, katana | `wayback_urls.txt` |

### Phase 2 — Enumeration

| Module | Purpose | Tools | Output |
|--------|---------|-------|--------|
| `enum.webcrawl` | Spider all live hosts | katana, hakrawler | `crawled_urls.txt` |
| `enum.js_analysis` | Extract endpoints, secrets, keys from JS | subjs, linkfinder | `endpoints.txt`, `secrets.json` |
| `enum.params` | Discover hidden GET/POST parameters | arjun, gf | `params.txt` |
| `enum.dirfuzz` | Discover hidden directories & files | ffuf, feroxbuster | `dir_results.txt` |
| `enum.api_endpoints` | OpenAPI specs, GraphQL introspection | curl, nuclei | `api_endpoints.json` |

### Phase 3 — Vulnerability Scanning

| Module | Purpose | Tools | Severity |
|--------|---------|-------|----------|
| `vuln.xss` | Reflected, DOM, blind XSS + SSTI | dalfox, nuclei | High |
| `vuln.sqli` | Error, blind, time-based injection | sqlmap | Critical |
| `vuln.ssrf` | URL param & header SSRF | Interactsh, nuclei | High |
| `vuln.idor` | Object reference enumeration | custom fuzzer | High |
| `vuln.auth` | JWT, OAuth, brute-force logic | jwt-tool, nuclei | Critical |
| `vuln.business_logic` | Race conditions, price manipulation | Turbo Intruder hints | Varies |
| `vuln.open_redirect` | Redirect param abuse | custom, nuclei | Medium |
| `vuln.lfi` | Path traversal, file inclusion | ffuf payloads | High |

---

## Pipeline System

Pipelines are declarative YAML files that chain modules together.

### Key concepts

- **Stages** — each stage maps to one module
- **depends_on** — stage waits for listed stages to complete
- **condition** — evaluates previous results before running
- **on_failure: continue | abort** — control blast radius
- **Checkpointing** — state saved after every stage; use `--resume` to continue
- **timeout** — per-stage timeout in seconds

### Example pipeline snippet

```yaml
stages:
  - id: recon_subdomains
    name: "Subdomain Enumeration"
    module: recon.subdomains
    on_failure: continue
    args:
      passive_only: false

  - id: enum_js
    name: "JavaScript Analysis"
    module: enum.js_analysis
    depends_on: [recon_subdomains]
    condition: "results.recon_subdomains.findings | length > 0"
    args:
      deep_analysis: false
```

---

## Installation

```bash
# 1. Clone the repo
git clone https://github.com/spondonsaha/spondonfw.git
cd spondonfw

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install Python dependencies
pip install -r requirements.txt
pip install -e .

# 4. Verify install
spondonfw --help

# 5. (Optional) Install Go tools
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install github.com/hahwul/dalfox/v2@latest
go install github.com/tomnomnom/assetfinder@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/lc/gau/v2/cmd/gau@latest
```

---

## CLI Usage

```bash
# Full methodology scan
spondonfw scan full --target example.com

# Full scan with custom rate limit & resume
spondonfw scan full --target example.com --rate-limit 5 --resume

# Recon only
spondonfw scan recon --target example.com

# Run a single module
spondonfw scan module --target example.com --module recon.subdomains

# Run JS analysis with deep mode enabled
spondonfw scan module --target example.com \
  --module enum.js_analysis \
  --args '{"deep_analysis": true}'

# Enumerate with a pre-built subdomain list
spondonfw scan enum --target example.com --subdomains subs.txt

# Vuln scan with specific checks
spondonfw scan vulnscan --target example.com --checks xss,ssrf,idor

# Generate HTML report from session
spondonfw report generate --session <SESSION_ID> --format html

# List all sessions
spondonfw session list

# List all modules
spondonfw module list

# Module info
spondonfw module info recon.subdomains

# Store API keys
spondonfw config set-key shodan YOUR_SHODAN_KEY
spondonfw config set-key github YOUR_GITHUB_TOKEN

# Install a plugin
spondonfw plugin install https://github.com/you/spondonfw-nuclei-plus
```

---

## Plugin System

Create a plugin by writing a `BaseModule` subclass + `plugin.yaml`:

```yaml
# plugins/my_plugin/plugin.yaml
name: my_plugin
version: "1.0.0"
description: "Custom S3 bucket enumerator"
entry: module.S3Enumerator
register_as: "plugin.s3_enum"
author: "Your Name"
tags: [recon, cloud, s3]
```

```python
# plugins/my_plugin/module.py
from core.engine.base_module import BaseModule, ModuleResult

class S3Enumerator(BaseModule):
    name = "plugin.s3_enum"
    description = "Enumerate S3 buckets for a target"
    tools_required = ["aws-cli"]

    def execute(self, ctx):
        result = ModuleResult(self.name, ctx["target"])
        # ... your logic here ...
        result.add_finding("s3_bucket", "target-backup", severity="high")
        return result
```

Then install: `spondonfw plugin install plugins/my_plugin`

---

## API Key Management

Keys are stored in `~/.spondonfw/keys.json` (chmod 600) and can also be
set via environment variables:

| Service | CLI command | Env var |
|---------|------------|---------|
| Shodan | `spondonfw config set-key shodan KEY` | `SHODAN_API_KEY` |
| GitHub | `spondonfw config set-key github TOKEN` | `GITHUB_TOKEN` |
| Censys | `spondonfw config set-key censys_id ID` | `CENSYS_API_ID` |
| Interactsh | `spondonfw config set-key interactsh URL` | `INTERACTSH_URL` |

Environment variables always take priority over stored keys.

---

## Improvements over Ars0n Framework

| Feature | Ars0n | SpondonFW |
|---------|-------|-----------|
| Methodology enforcement | Partial (hardcoded) | Full YAML-driven, matches your exact flow |
| Module granularity | Coarse | Fine-grained; each task is its own module |
| Dependency graph | Linear | DAG-based with `depends_on` + `condition` |
| Resume support | No | Full checkpoint/resume per stage |
| Plugin system | No | Yes — git URL or local path install |
| API key management | Env-only | Encrypted keystore + env override |
| Reporting | Basic | HTML/JSON/Markdown with severity charts |
| Condition evaluation | No | Yes — skip stages based on previous results |
| Rate limiting | Basic | Token-bucket per module |
| Multi-target | Limited | Native — run pipeline per target in loop |
| AI prioritization | No | Roadmap — severity scoring via Claude API |

---

## Roadmap

### v1.1 — Async + Parallelism
- [ ] `asyncio`-based HTTP modules for 10× speed
- [ ] Celery + Redis task queue for parallel stage execution
- [ ] `--workers N` flag for concurrent module runs

### v1.2 — AI-Assisted Triage
- [ ] Integrate Claude API to score and prioritise findings
- [ ] Auto-generate PoC report drafts from findings
- [ ] Noise filter: de-duplicate informational findings

### v1.3 — Dashboard
- [ ] React + Vite GUI
- [ ] Real-time scan progress via WebSockets
- [ ] Finding explorer with filters, export, and notes

### v1.4 — Smart Recon
- [ ] Context-aware scanning (skip vuln modules if no params found)
- [ ] Technology fingerprint → suggest relevant modules only
- [ ] Continuous monitoring mode with diff alerts

### v1.5 — Collaboration
- [ ] PostgreSQL backend for team sharing
- [ ] Multi-user session access
- [ ] Slack/Discord/Telegram notifications per finding
